   .model small
.stack 100h
.code
main proc
    mov ah, 2
    mov dl, 'A'

    mov cx, 5       ; repeat 5 times

print_loop:
    int 21h         ; print 'A'
    loop print_loop 

    mov ah, 4Ch
    int 21h
main endp
end main
