      .model small
.stack 100h
.data
    msgGreater db 'Greater$'
    msgSmaller db 'Smaller$'
    msgEqual   db 'Equal$'
.code
main proc
    mov ax, @data
    mov ds, ax

    ; input first number
    mov ah, 1
    int 21h
    sub al, 30h
    mov bl, al       ; store first number in BL

    ; input second number
    mov ah, 1
    int 21h
    sub al, 30h
    mov bh, al       ; store second number in BH

    cmp bl, bh
    jg greater_label
    jl smaller_label
    je equal_label

greater_label:
    mov dx, offset msgGreater
    mov ah, 9
    int 21h
    jmp end_prog

smaller_label:
    mov dx, offset msgSmaller
    mov ah, 9
    int 21h
    jmp end_prog

equal_label:
    mov dx, offset msgEqual
    mov ah, 9
    int 21h

end_prog:
    mov ah, 4Ch
    int 21h
main endp
end main
