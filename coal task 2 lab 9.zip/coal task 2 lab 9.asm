     .model small
.stack 100h
.data
    msgPos db 'Positive$'
    msgNeg db 'Negative$'
.code
main proc
    mov ax, @data
    mov ds, ax

    ; take input from user
    mov ah, 1
    int 21h          ; read character into AL
    sub al, 30h      ; convert ASCII to number

    cmp al, 0
    jl neg_label     ; if < 0 ? Negative
    jmp pos_label    ; else ? Positive

pos_label:
    mov dx, offset msgPos
    mov ah, 9
    int 21h
    jmp end_prog

neg_label:
    mov dx, offset msgNeg
    mov ah, 9
    int 21h

end_prog:
    mov ah, 4Ch
    int 21h
main endp
end main
