   .model small
.stack 100h
.data
arr db 5 dup(?)

.code
main proc
    mov ax,@data
    mov ds,ax

    mov si,0
    mov cx,5

read_loop:
    mov ah,1
    int 21h
    sub al,48
    mov arr[si],al
    inc si
    loop read_loop

    mov si,4
    mov cx,5
print_loop:
    mov dl,arr[si]
    add dl,48
    mov ah,2
    int 21h
    dec si
    loop print_loop

    mov ah,4Ch
    int 21h
main endp
end main
