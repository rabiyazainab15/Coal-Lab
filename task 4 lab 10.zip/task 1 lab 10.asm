.model small
.stack 100h
.data
arr db 5 dup(?)
sum dw 0

.code
main proc
    mov ax,@data
    mov ds,ax

    mov si,0
    mov cx,5

read_loop:
    mov ah,1        ; read digit
    int 21h
    sub al,48       ; ASCII ? number
    mov arr[si],al
    mov ah,0
    add sum,ax
    inc si
    loop read_loop

    ; print sum (multi-digit)
    mov ax,sum
    mov bx,10
    mov dx,0

print_loop:
    div bx
    push dx
    cmp ax,0
    jne print_loop

print_digits:
    pop dx
    add dl,48
    mov ah,2
    int 21h
    cmp sp,100h
    jne print_digits

    mov ah,4Ch
    int 21h
main endp
end main
