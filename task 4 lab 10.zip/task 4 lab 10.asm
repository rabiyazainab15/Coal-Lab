   .model small
.stack 100h
.data
arr db 5 dup(?)
count db 0

.code
main proc
    mov ax,@data
    mov ds,ax

    mov si,0
    mov cx,5

read_loop:
    mov ah,1
    int 21h
    sub al,48
    mov arr[si],al

    mov bl,al
    mov ah,0
    mov al,bl
    mov bl,2
    div bl        ; remainder in ah
    cmp ah,0
    jne skip
    inc count
skip:
    inc si
    loop read_loop

    mov dl,count
    add dl,48
    mov ah,2
    int 21h

    mov ah,4Ch
    int 21h
main endp
end main
