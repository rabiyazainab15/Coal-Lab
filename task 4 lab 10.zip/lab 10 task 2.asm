       .model small
.stack 100h
.data
arr db 5 dup(?)
largest db ?

.code
main proc
    mov ax,@data
    mov ds,ax

    mov si,0
    mov cx,5

read_loop:
    mov ah,1
    int 21h
    sub al,48
    mov arr[si],al

    cmp si,0
    jne check
    mov largest,al
check:
    cmp al,largest
    jle skip
    mov largest,al
skip:
    inc si
    loop read_loop

    mov dl,largest
    add dl,48
    mov ah,2
    int 21h

    mov ah,4Ch
    int 21h
main endp
end main
