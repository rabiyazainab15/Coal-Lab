  .model small
.stack 100h
.data
    char db 'A'          ; starting character
    newline db 0Dh,0Ah,'$'  ; carriage return + line feed
.code
main proc
    mov ax, @data
    mov ds, ax

    mov cl, 26            ; loop counter for 26 letters

print_loop:
    mov dl, char          ; load current character
    mov ah, 2             ; function to display character
    int 21h

    mov dx, offset newline ; print newline
    mov ah, 9
    int 21h

    inc char              ; move to next character
    dec cl
    jnz print_loop

    mov ah, 4Ch           ; exit program
    int 21h
main endp
end main
