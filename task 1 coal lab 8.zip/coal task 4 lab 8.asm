.model small
.stack 100h
.data
    space db ' $'          ; space after each number
.code
main proc
    mov ax, @data
    mov ds, ax

    mov cl, 0              ; start from 0

print_loop:
    mov dl, cl             ; copy number into DL
    add dl, 30h            ; convert to ASCII digit
    mov ah, 2
    int 21h                ; print the digit

    mov dx, offset space   ; print space
    mov ah, 9
    int 21h

    add cl, 2              ; increment by 2
    cmp cl, 10             ; stop when >= 10
    jl print_loop

    mov ah, 4Ch            ; exit program
    int 21h
main endp
end main
