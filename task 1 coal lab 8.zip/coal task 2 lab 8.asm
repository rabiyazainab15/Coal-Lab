   .model small
.stack 100h
.data
.code
main proc
    mov cx, 5        ; loop 5 times
    mov dl, '*'      

loop2:
    mov ah, 2
    int 21h          ; print *

    loop loop2       ; repeat

    mov ah, 4ch
    int 21h
main endp
end main