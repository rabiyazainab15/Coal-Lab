.model small
.stack 100h
.data
.code
main proc
    mov dl, '9'      ; start from 9

loop1:
    mov ah, 2
    int 21h          ; print character

    dec dl           ; go backwards

    cmp dl, '0'-1    ; stop after printing 0
    jne loop1

    mov ah, 4ch
    int 21h
main endp
end main